/*:

 # The Basics
 [The Swift Programming Language](https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/StringsAndCharacters.html#)
 
 * Hello, world!
 * Constants and Variables
 * Type Annotation & Type Inference
 * Literals & Types
 * Type Conversion
 ---
 * Basic Operators
 * Function
 */


//: [Next](@next)
